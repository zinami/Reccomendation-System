import dash
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import numpy as np
import pandas as pd
import plotly.graph_objs as go
import pandas as pd
import plotly.express as px

from app import app
from app import server
import home

# https://htmlcheatsheet.com/css/

######################################################Data##############################################################

df = pd.read_csv('retail.csv')
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], unit='ms')
df = df.astype({'CustomerID': object, 'StockCode': object})
df.rename(columns={'InvoiceNo': 'TransactionId', 'StockCode': 'ItemId', 'InvoiceDate': 'TransactionDate'}, inplace=True)


######################################################Interactive Components############################################


##################################################APP###################################################################

def products():
    top10prod = df["Description"].value_counts().to_frame().head(15)
    top10prod = top10prod.rename(columns={"Description": "Total Amount of Sales"})

    fig = px.bar(top10prod, x=top10prod.index, y='Total Amount of Sales', color='Total Amount of Sales')
    fig.update_traces(showlegend=False)
    fig.update_layout(barmode='stack', paper_bgcolor='rgba(255,255,255)', plot_bgcolor='rgba(0,0,0,0)',
                      xaxis_title="Product Name",
                      yaxis_title="Total Amount of Sales")
    fig.update_traces(
        hovertemplate='Product: %{x} <br>Total Sales: %{y} <extra></extra>')
    fig.update_yaxes(gridcolor='black', showgrid=True, gridwidth=0.5)
    return fig

def countries_plot():
    countries = df["Country"]
    countries = countries.value_counts().to_frame()
    countries = countries.rename(columns={"Country": "Amount of Sales for Country"})

    fig2 = px.bar(countries, x=countries.index, y='Amount of Sales for Country', color='Amount of Sales for Country')
    fig2.update_traces(showlegend=False)
    fig2.update_layout(barmode='stack', paper_bgcolor='rgba(255,255,255)', plot_bgcolor='rgba(0,0,0,0)',
                      xaxis_title="Country",
                      yaxis_title="Amount of Sales for Country")
    fig2.update_traces(
        hovertemplate='Country: %{x} <br> Sales for Country: %{y} <extra></extra>')
    fig2.update_yaxes(gridcolor='black', showgrid=True, gridwidth=0.5)
    return fig2

def countries10():
    countries = df["Country"]
    countries = countries.value_counts().to_frame()
    countries = countries.rename(columns={"Country": "Amount of Sales for Country"})
    countries10 = countries.head(10)
    fig3 = px.pie(countries10, values='Amount of Sales for Country', names=countries10.index)
    fig3.update_traces(
        hovertemplate='')
    return fig3

prices = df["UnitPrice"].value_counts().to_frame()
prices = prices.rename(columns={"UnitPrice":"Amount of Sales for Price"})
prices["Prices"] = prices.index

prods = len(df["Description"].value_counts().to_frame())

coun = df["Country"]
coun = coun.value_counts().to_frame()
coun = coun.rename(columns={"Country":"Amount of Sales for Country"})
coun = len(coun)

num_cust=df["CustomerID"].value_counts()
num_cust

df["hours"]=df["TransactionDate"].dt.hour
df['Day of Week'] = df['TransactionDate'].dt.day_name()
grouped_df = df.groupby(["hours", "Day of Week"])["TransactionId"].aggregate("count").reset_index()

def heatmap():
    fig4 = go.Figure(data=go.Heatmap(
        x=grouped_df["hours"],
        y=grouped_df["Day of Week"],
        z=grouped_df["TransactionId"],
        type='heatmap',
        colorscale='Viridis'))
    fig4.update_traces(
        hovertemplate='Hour: %{x} <br>Day of Week: %{y} <br>Sales: %{z} <extra></extra>')
    fig4.update_yaxes(gridcolor='black', showgrid=False, gridwidth=0.5)
    fig4.update_xaxes(gridcolor='black', showgrid=False, gridwidth=0.5)
    return fig4

df['month_year'] = pd.to_datetime(df['TransactionDate']).dt.to_period('M')
g = df.groupby(df['month_year'])
g = g.sum()
d = {'year_month': ['2010-12', '2011-01', '2011-02', '2011-03', '2011-04', '2011-05',
             '2011-06', '2011-07', '2011-08', '2011-09', '2011-10', '2011-11',
             '2011-12'], 'Quantity': [342228,
 308966,
 277989,
 351872,
 289098,
 380391,
 341623,
 391116,
 406199,
 549817,
 570532,
 740286,
 226333]}
d = pd.DataFrame(data=d)

def bar_chart_Year_month():
    fig5 = px.line(d, x="year_month", y='Quantity')
    fig5.update_traces(showlegend=False, line=dict(color='royalblue', width=4))
    fig5.update_layout(paper_bgcolor='rgba(255,255,255)', plot_bgcolor='rgba(0,0,0,0)', xaxis_title="Month and Year",
                      yaxis_title="Quantity Sold")
    
    fig5.update_traces(
        hovertemplate='Month and Year: %{x} <br>Quantity: %{y} <extra></extra>')
    fig5.update_yaxes(gridcolor='black', showgrid=True, gridwidth=0.5)
    return fig5

layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H1('ManyGiftsUK Visualization Dashboard', className="text-left")
        ], width=12)
    ]),
    dbc.Row([
        dbc.Col([
            dbc.Card(
                dcc.Graph(figure=products(), style={'height': 570}),
                body=True, color="#1450a0"
            )
        ], width={'size': 6}, className='my-2'),
        dbc.Col([dbc.Row([
                dbc.Col([dbc.Card(
                    dbc.CardBody([
                    html.H2(str(max(prices["Prices"])) + " €", className="text-center"),
                    html.H3("Most expensive product avaliable in stock in ManyGiftsUK", className="text-center")
                        ]),
                body=True, color="#1450a0"
            )],width={'size': 6} , className='mt-2 mb-5'),
                dbc.Col([dbc.Card(
                    dbc.CardBody([
                        html.H2(str(prods), className="text-center"),
                        html.H3("Number of different products in stock in ManyGiftsUK", className="text-center")
                    ]),
                body=True, color="#1450a0"
            )],width={'size': 6}, className='mt-2 mb-5')
            ]),
            dbc.Row([
                dbc.Col([dbc.Card(
                    dbc.CardBody([
                        html.H2(str(coun), className="text-center"),
                        html.H3("Number of Countries that have purchased from ManyGiftsUK", className="text-center")
                    ]),
                body=True, color="#1450a0"
            )],width={'size': 6}, className='mt-5'),
                dbc.Col([dbc.Card(
                    dbc.CardBody([
                        html.H2(str(len(num_cust)), className="text-center"),
                        html.H3("Number of clients that made purchases in ManyGiftsUK", className="text-center")
                    ]),
                body=True, color="#1450a0"
            )],width={'size': 6}, className='mt-5')
            ])])
    ], className="mb-2"),
    dbc.Row([
            dbc.Col([
                dbc.Card(
                    dcc.Graph(figure=countries_plot(), style={'height': 570}),
                    body=True, color="#1450a0"
                )
            ], width={'size': 6}, className='my-2'),
            dbc.Col([
                dbc.Card(
                    dcc.Graph(figure=heatmap(), style={'height': 570}),
                    body=True, color="#1450a0"
                )
            ], width={'size': 6}, className='my-2'),
        ], className="mb-2"),
    dbc.Row([
        dbc.Col([
            dbc.Card(
                dcc.Graph(figure=bar_chart_Year_month(), style={'height': 570}),
                body=True, color="#1450a0"
            )
        ], width=12, className='my-2')
    ]),


], fluid=True)
